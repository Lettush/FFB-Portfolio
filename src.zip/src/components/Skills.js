const Skills = () => {
    return (
        <>
            <h3 className="skills-heading">My Skills</h3>
            <table className="skills">
                <tr>
                    <th>Heading 1</th>
                    <th>Heading 2</th>
                    <th>Heading 3</th>
                </tr>
                <tr>
                    <td>HTML</td>
                    <td>CSS</td>
                    <td>JS</td>
                </tr>
                <tr>
                    <td>Teaching</td>
                    <td>Time Management</td>
                    <td>Creativity</td>
                </tr>
            </table>
        </>
    );
};

export default Skills;
