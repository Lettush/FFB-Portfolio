const Works = () => {
    return (
        <>
            <h3 className="work-heading">My Works</h3>
            <div className="works">
                <div className="work">
                    <h4>Work #1</h4>
                    <p>
                        Lorem ipsum dolor sit amet, consectetur adipisicing
                        elit. Enim unde vitae vel molestias! Iusto, magnam
                        mollitia.
                    </p>
                </div>
                <div className="work">
                    <h4>Work #2</h4>
                    <p>
                        Lorem ipsum dolor sit amet, consectetur adipisicing
                        elit. Enim unde vitae vel molestias! Iusto, magnam
                        mollitia.
                    </p>
                </div>
                <div className="work">
                    <h4>Work #3</h4>
                    <p>
                        Lorem ipsum dolor sit amet, consectetur adipisicing
                        elit. Enim unde vitae vel molestias! Iusto, magnam
                        mollitia.
                    </p>
                </div>
            </div>
        </>
    );
};

export default Works;
