const Experience = () => {
    return (
        <>
            <h3 className="exp-heading">My Experience</h3>
            <div className="exp">
                <h4>Company/Project #1</h4>
                <p>
                    Lorem ipsum dolor sit amet consectetur adipisicing elit.
                    Quod esse cumque voluptas.
                </p>
                <a href="#">Live Demo</a>
            </div>
            <div className="exp">
                <h4>Company/Project #2</h4>
                <p>
                    Lorem ipsum dolor sit amet consectetur adipisicing elit.
                    Quod esse cumque voluptas.
                </p>
                <a href="#">Live Demo</a>
            </div>
            <div className="exp">
                <h4>Company/Project #3</h4>
                <p>
                    Lorem ipsum dolor sit amet consectetur adipisicing elit.
                    Quod esse cumque voluptas.
                </p>
                <a href="#">Live Demo</a>
            </div>
        </>
    );
};

export default Experience;